from . import pos_credit_sale
#import pos_receipt
