# -*- encoding: utf-8 -*-

from . import hotel_laundry_picking

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: