# -*- coding: utf-8 -*-

from . import hotel_dashboard

