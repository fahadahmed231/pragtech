
17.0.0.1 ==> Fixed issue of when done any incoming shipment at that time wrong qty updated in stock.quant and move line also.

17.0.0.2 ==> Fixed issue of when we chnage branch from header at that time in user branch can't be updated.